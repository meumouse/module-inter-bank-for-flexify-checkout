Versão 1.3.4 (29/10/2025)
* Correção de bugs
    - Duplicidade de informações do Pix em e-mails e página de agradecimento do pedido
* Otimizações
* Alteração da API de consulta de atualizações 

Versão 1.3.3 (31/08/2025)
* Correção de bugs
    - Duplicidade de informações do Pix na página de agradecimento

Versão 1.3.2 (12/08/2025)
* Correção de bugs
    - Reconstrução da lista de gateways para evitar cache antecipado pelo Mercado Pago
* Otimizações

Versão 1.3.1 (07/08/2025)
* Recurso adicionado: Prevenção contra quebra do site por dependência desatualizada

Versão 1.3.0 (05/08/2025)
* Correção de bugs
* Compatibilidade com Flexify Checkout v5.0.0

Versão 1.2.7 (02/09/2024)
* Correção de bugs

Versão 1.2.6 (30/08/2024)
* Correção de bugs

Versão 1.2.5 (30/08/2024)
* Correção de bugs
* Recurso removido: Classe Error_Handler

Versão 1.2.2 (29/08/2024)
* Correção de bugs
* Recurso adicionado: Classe Error_Handler para lidar com erros críticos e prevenir quebras no site

Versão 1.2.0 (22/08/2024)
* Correção de bugs
* Otimizações

Versão 1.1.0 (24/07/2024)
* Correção de bugs
* Otimizações
* Recurso modificado: Boleto bancário com Pix (Atualização na API do banco Inter: https://developers.inter.co/references/cobranca)

Versão 1.0.0 inicial (20/02/2024)