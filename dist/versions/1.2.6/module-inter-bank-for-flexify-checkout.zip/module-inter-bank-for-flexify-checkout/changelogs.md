Versão 1.2.6 (30/08/2024)
* Correção de bugs

Versão 1.2.5 (30/08/2024)
* Correção de bugs
* Recurso removido: Classe Error_Handler

Versão 1.2.2 (29/08/2024)
* Correção de bugs
* Recurso adicionado: Classe Error_Handler para lidar com erros críticos e prevenir quebras no site

Versão 1.2.0 (22/08/2024)
* Correção de bugs
* Otimizações

Versão 1.1.0 (24/07/2024)
* Correção de bugs
* Otimizações
* Recurso modificado: Boleto bancário com Pix (Atualização na API do banco Inter: https://developers.inter.co/references/cobranca)

Versão 1.0.0 inicial (20/02/2024)