<?php

namespace Module_Inter_Bank\Traits;

defined( 'ABSPATH' ) || exit;

trait Helpers {
	/**
	 * Get order document
	 *
	 * @since 2.3.0
	 * @param string|int $order | Order ID
	 * @return string|int
	 */
	protected function get_order_document( $order ) {
    	$person_type = intval( $order->get_meta( '_billing_persontype' ) );
		$document = null;

		if ( 1 === $person_type ) {
			$document = $order->get_meta( '_billing_cpf' );
		} elseif ( 2 === $person_type ) {
			$document = $order->get_meta( '_billing_cnpj' );
		} else {
			$document = $order->get_meta( '_billing_cpf' );

			if ( empty ( $document ) ) {
				$document = $order->get_meta( '_billing_cnpj' );
			}
		}

    	return $this->only_numbers( $document );
	}


	/**
	 * Only numbers.
	 *
	 * @since 2.3.0
	 * @param  string|int $string String to convert.
	 * @return string|int
	 */
	protected function only_numbers( $string ) {
		return preg_replace( '([^0-9])', '', $string );
	}
}