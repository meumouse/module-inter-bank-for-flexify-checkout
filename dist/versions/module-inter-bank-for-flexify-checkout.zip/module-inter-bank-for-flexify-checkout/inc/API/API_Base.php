<?php

namespace Module_Inter_Bank\API;

use Exception;
use Module_Inter_Bank\Traits\Helpers;
use Module_Inter_Bank\Traits\Logger;

defined( 'ABSPATH' ) || exit;

abstract class API_Base {
  use Helpers, Logger;


	/**
	 * API token scpe.
	 *
	 * @var string
	 */
  protected $token_scope = 'webhook.write webhook.read cob.write cob.read boleto-cobranca.read boleto-cobranca.write';


	/**
	 * Authentication endpoint
	 *
	 * @var string
	 */
  protected $auth_endpoint = 'oauth/v2/token';


	/**
	 * API URL.
	 *
	 * @var string
	 */
	protected $api_url = 'https://cdpj.partners.bancointer.com.br/';

	/**
	 * Gateway class.
	 *
	 * @var WC_Payment_Gateway
	 */
	protected $gateway;

	/**
	 * Constructor.
	 *
	 * @param WC_Payment_Gateway $gateway Gateway instance.
	 */
	public function __construct( $gateway = null ) {
		$this->gateway = $gateway;

    if ( $this->gateway ) {
      $critical_only = ! $this->gateway->debug;
      $this->set_logger_source( $this->gateway->id, $critical_only );
    }

    add_action( 'http_api_curl', array( $this, 'inter_http_api_curl' ), 10, 3 );
	}

	/**
	 * Get API URL.
	 *
	 * @return string
	 */
	public function get_api_url() {
		return $this->api_url;
	}


  protected function get_token() {
    $transient_name = 'module_inter_bank_token_' . $this->gateway->id;
    $token_data = get_transient( $transient_name );

    /**
     * 1. Token is valid on WordPress
     * 2. Token is expired but WordPress failed to remove it
     * 3. Plugin scope is different!
     */
    if ( false === $token_data || $token_data['expires_at'] < time() || $token_data['scope'] !== $this->token_scope ) {
      $this->log( 'Solicitando novo token... ' . print_r( $token_data, true ) );

      $data = [
        'client_id' => $this->gateway->client_id,
        'client_secret' => $this->gateway->client_secret,
        'grant_type' => 'client_credentials',
        'scope' => $this->token_scope,
      ];

      $headers = [
        'Content-Type' => 'application/x-www-form-urlencoded',
      ];

      $response = $this->do_request( $this->auth_endpoint . '?current_method=' . $this->gateway->id, 'POST', $data, $headers );

      if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
        $this->log( 'Erro ao solicitar token ' . print_r( $response, true ) );

        throw new Exception( __( 'Ocorreu um erro ao entrar em contato com o Banco emissor. Por favor, tente novamente', 'flexify-checkout-for-woocommerce' ) );
      }

      $body = json_decode( $response['body'] );

      $token_data = [
        'token' => $body->access_token,
        'scope' => $body->scope,
        'expires_at' => time() + $body->expires_in,
      ];

      set_transient( $transient_name, $token_data, $body->expires_in );
    }

    return $token_data['token'];
  }


  /**
	 * Process API Requests.
	 *
	 * @param string $url      URL.
	 * @param string $method   Request method.
	 * @param array  $data     Request data.
	 * @param array  $headers  Request headers.
	 * @return object|Exception Request response.
	 */
	protected function do_request( $endpoint, $method = 'POST', $data = [], $headers = [] ) {
		$url = $this->get_api_url() . $endpoint;

    $this->log( 'URL: ' . $url . ' (' . $method . ')' );

		$params = [
			'method'  => $method,
			'timeout' => 60,
			'headers' => [
				'Accept' => 'application/json',
				'Content-Type' => 'application/json',
			],
		];

    if ( false === strpos( $endpoint, $this->auth_endpoint ) ) {
      $params['headers']['Authorization'] = 'Bearer ' . $this->get_token();
    }

		if ( in_array( $method, [ 'POST', 'PUT' ] ) && ! empty( $data ) ) {
			$params['body'] = wp_json_encode( $data );
		}

		if ( ! empty( $headers ) ) {
			$params['headers'] = wp_parse_args( $headers, $params['headers'] );
		}

    if ( $params['headers']['Content-Type'] === 'application/x-www-form-urlencoded' && ! empty( $data ) ) {
      $params['body'] = http_build_query( $data );
    } elseif ( $params['method'] === 'GET' ) {
      $url = add_query_arg( $data, $url );
    }

    $response = wp_safe_remote_post( $url, $params );

    if ( is_wp_error( $response ) ) {
      $this->log( 'WP Error on enpoint ' . $endpoint . ': ' . print_r( $response, true ), 'emergency' );

      throw new Exception( $response->get_error_message(), 500 );
    }

    if ( wp_remote_retrieve_response_code( $response ) >= 400 ) {
      $body = json_decode( $response['body'] );

      $message = __( 'Ocorreu um erro de processamento: ', 'flexify-checkout-for-woocommerce' );

      if ( ! empty( $body->violacoes ) ) {
        $message .= implode( ';', array_map( function( $violation ) {
          return $violation->razao;
        }, $body->violacoes ) );
      }

      // authorization errors
      if ( ! empty( $body->error_title ) && current_user_can( 'manage_woocommerce' ) ) {
        $message .= $body->error_title;
      }

      // pix errors
      if ( ! empty( $body->title ) && current_user_can( 'manage_woocommerce' ) ) {
        $message .= $body->title;

        if ( ! empty( $body->detail ) ) {
          $message .= $body->detail;
        }
      }

      $message .= __( ' Tente novamente.', 'flexify-checkout-for-woocommerce' );

      $this->log( 'Invalid response on enpoint ' . $endpoint . ': ' . wp_remote_retrieve_response_code( $response ) . ': ' . print_r( $body, true ), 'emergency' );

      throw new Exception( $message, 500 );
    }

		return $response;
	}




  public function inter_http_api_curl( $handle, $r, $url ) {
    if ( false !== strpos( $url, $this->get_api_url() ) && ( false !== strpos( $url, $this->gateway->endpoint ) || false !== strpos( $url, 'current_method=' . $this->gateway->id ) ) ) {
      curl_setopt( $handle, CURLOPT_SSLCERT, $this->gateway->cert_crt );
      curl_setopt( $handle, CURLOPT_SSLKEY, $this->gateway->cert_key );
    }
  }
}
