<?php

namespace Module_Inter_Bank\API;

use Exception;

defined( 'ABSPATH' ) || exit;

class Bank_Slip_API extends API_Base {

  /**
   * Create new Bank Slip
   *
   * @return void
   */
  public function create( $order ) {
    $document    = $this->get_order_document( $order );
    $person_type = (strlen( $document ) > 11 ) ? 'JURIDICA' : 'FISICA';

    if ( ! $document ) {
      throw new Exception( __( 'Informe seu documento para prosseguir.', 'flexify-checkout-for-woocommerce' ) );
    }

    $full_name = $order->get_formatted_billing_full_name();
    $name = 'FISICA' === $person_type ? $full_name : $order->get_billing_company();

    $billing_address = $order->get_address( 'billing' );
    $expire_date = $this->get_expire_date( $this->gateway->expires_in );

    $data = [
      'seuNumero'      => $order->get_id(),
      'valorNominal'   => $order->get_total(),
      'dataVencimento' => $expire_date,
      'numDiasAgenda'  => 0,
      'pagador'        => [
        'cpfCnpj'     => $document,
        'tipoPessoa'  => $person_type,
        'nome'        => $name ? $name : $full_name,
        'endereco'    => $billing_address['address_1'],
        'numero'      => substr( $billing_address['number'], 0, 10 ),
        'complemento' => substr( $billing_address['address_2'], 0, 30 ),
        'bairro'      => substr( $billing_address['neighborhood'], 0, 60 ),
        'cidade'      => $billing_address['city'],
        'uf'          => $billing_address['state'],
        'cep'         => $this->only_numbers( $billing_address['postcode'] ),
        'email'       => $order->get_billing_email(),
        'ddd'         => '',
        'telefone'    => '',
      ],
      'mensagem' => [],
    ];

    $line = 1;
    foreach ( $this->gateway->ticket_messages as $message ) {
      if ( ! trim( $message ) ) {
        break;
      }

      $data['mensagem']['linha' . $line ] = substr( str_replace( '{order_id}', $order->get_order_number(), $message ), 0, 78 );

      // make sure the is no more than 4 lines
      if ( 5 === $line ) {
        break;
      }

      $line++;
    }

    $data = apply_filters( $this->gateway->id . '_request_args', $data, $order, $this );

    $this->log( 'Novo pedido: ' . print_r( $data, true ), 'emergency' );

    $response = $this->do_request( 'cobranca/v2/boletos', 'POST', $data );
    $result   = json_decode( $response['body'] );

    if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
      $this->log( 'A resposta da API do Inter não foi 200: ' . print_r( $response, true ), 'emergency' );

      throw new Exception( __( 'Ocorreu um erro ao gerar o boleto. Tente novamente.', 'flexify-checkout-for-woocommerce' ) );
    }

    if ( empty( $result->nossoNumero ) || empty( $result->linhaDigitavel ) ) {
      $this->log( 'A resposta da API do Inter está vazia! ' . print_r( $response, true ), 'emergency' );

      throw new Exception( __( 'Ocorreu um erro ao processar os dados do boleto. Tente novamente', 'flexify-checkout-for-woocommerce' ) );
    }

    $this->log( 'response: ' . print_r( $result, true ) );

    return $result;
  }

  /**
   * Exclude a bank slip
   *
   * @param int $id Nosso Número
   * @return bool
   */
  public function delete( $id ) {

  }

  /**
   * Get a bank slip
   *
   * @param int $id Nosso Número
   * @return bool
   */
  public function get( $id, $type = 'pdf' ) {
    $this->log( 'Consultando boleto ' . $id );

    $response = $this->do_request( 'cobranca/v2/boletos/' . $id . '/' . $type, 'GET' );

    if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
      throw new Exception( __( 'Ocorreu um erro ao consultar o boleto', 'flexify-checkout-for-woocommerce' ) );
    }

    return json_decode( $response['body'] );
  }



  public function get_expire_date( $additional_days ) {
    return date( 'Y-m-d', ( strtotime ( $additional_days . ' weekdays' ) ) );
  }



  public function get_all() {
    $response = $this->do_request( 'cobranca/v2/boletos?dataInicial=2023-01-01&dataFinal=' . date( 'Y-m-d' ) . '&itensPorPagina=1000&filtrarDataPor=EMISSAO&ordenarPor=SEUNUMERO&tipoOrdenacao=DESC&situacao=PAGO', 'GET' );

    if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
      throw new Exception( __( 'Ocorreu um erro ao consultar boletos: ', 'flexify-checkout-for-woocommerce' ) . print_r( $response, true ) );
    }

    return json_decode( $response['body'] );
  }
}
