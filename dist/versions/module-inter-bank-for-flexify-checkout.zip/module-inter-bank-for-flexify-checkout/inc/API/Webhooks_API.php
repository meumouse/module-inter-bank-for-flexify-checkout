<?php

namespace Module_Inter_Bank\API;

use Exception;

defined( 'ABSPATH' ) || exit;

class Webhooks_API extends API_Base {
  public $endpoints = [
    'interpix' => 'pix/v2/webhook/',
    'interboleto' => 'cobranca/v2/boletos/webhook',
  ];


  /**
   * Get current webhook
   *
   * @return array
   */
  public function get() {
    $endpoints = $this->endpoints;

    if ( ! isset( $endpoints[ $this->gateway->id ] ) ) {
      throw new Exception( __( 'Método de pagamento inválido', 'flexify-checkout-for-woocommerce' ) );
    }

    // throw earlier if there is token issue
    $this->get_token();

    if ( 'interpix' === $this->gateway->id ) {
      if ( empty( $this->gateway->pix_key ) ) {
        throw new Exception( __( 'Informe a chave Pix antes de consultar o webhook', 'flexify-checkout-for-woocommerce' ) );
      }

      $endpoints['interpix'] .= $this->gateway->pix_key;
    }

    try {
      $response = $this->do_request( $endpoints[ $this->gateway->id ], 'GET' );
      $result   = json_decode( $response['body'], true );
    } catch (Exception $e) {
      return false;
    }

    return $result;
  }

  /**
   * Exclude current webhook
   *
   * @return bool
   */
  public function delete() {

  }

  /**
   * Create a webhook
   *
   * @param string $url Webhook URL
   * @return bool
   */
  public function create( $url ) {
    $endpoints = $this->endpoints;

    if ( ! isset( $endpoints[ $this->gateway->id ] ) ) {
      throw new Exception( __( 'Método de pagamento inválido para criar endpoint', 'flexify-checkout-for-woocommerce' ) );
    }

    if ( 'interpix' === $this->gateway->id ) {
      if ( empty( $this->gateway->pix_key ) ) {
        throw new Exception( __( 'Informe a chave Pix antes de consultar o webhook', 'flexify-checkout-for-woocommerce' ) );
      }

      $endpoints['interpix'] .= $this->gateway->pix_key;
    }

    $data = [
      'webhookUrl' => $url,
    ];

    $response = $this->do_request( $endpoints[ $this->gateway->id ], 'PUT', $data );

    if ( 204 !== wp_remote_retrieve_response_code( $response ) ) {
      throw new Exception( __( 'Ocorreu um erro ao gerar o webhook.', 'flexify-checkout-for-woocommerce' ) );
    }

    return true;
  }
}
