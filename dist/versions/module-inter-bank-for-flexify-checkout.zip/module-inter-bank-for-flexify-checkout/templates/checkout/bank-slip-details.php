<?php

defined( 'ABSPATH' ) || exit;

?>

<style>
.banco-inter-payment-created {
  display: block;
  margin-bottom: 20px;
  text-align: center;
  border: 1px solid #ccc;
  padding: 15px;
}
.banco-inter-payment-created .banco-inter-status {
  display: block;
}
.wc-print-banking-ticket-button {
  font-size: 1.25rem;
  width: 75%;
  height: 48px;
  line-height: 24px;
  text-align: center;
  display: block;
  margin: 20px 0;
  width: 100%;
}
.wc-linecode-title {
  display: block;
  text-align: center;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  font-size: 11px;
  margin-bottom: 5px;
}
#wc-linecode-field {
  width: 100%;
  text-align: center;
  border-radius: 5px;
  border: 1px solid #ccc;
  color: #4e4e4e;
  letter-spacing: 2px;
  resize: none;
}
.wc-copy-linecode-button {
  display: block;
  width: 100%;
  margin-top: 10px;
  margin-bottom: 40px;
  font-weight: bold;
  text-transform: uppercase;
  letter-spacing: 1px;
}
@media only screen and (min-width: 600px) {
  #wc-linecode-field {
    height: 45px;
  }
}
</style>

<script src="https://cdn.jsdelivr.net/npm/clipboard@2.0.10/dist/clipboard.min.js"></script>

<script>
  jQuery( function( $ ) {
    var clipboard = new ClipboardJS('.wc-copy-linecode-button');
    clipboard.on('success', function( e ) {
      $( '.wc-copy-linecode-button' ).html('Copiado!');

      window.setTimeout( function () {
        let button = $( '.wc-copy-linecode-button' );
        button.html( button.data( 'text' ) );
      }, 1500 );
    });
  });
</script>


<section id="<?php echo esc_attr( $id ); ?>-thankyou">
  <a target="_blank" href="<?php echo $url; ?>" class="button alt wc-print-banking-ticket-button"><?php echo __( 'Ver boleto (PDF)', 'flexify-checkout-for-woocommerce' ); ?></a>

  <span class="wc-linecode-title">Linha digitável</span>
  <textarea id="wc-linecode-field" rows="2"><?php echo $payment_line; ?></textarea>

  <button class="wc-copy-linecode-button" data-clipboard-target="#wc-linecode-field" data-text="<?php echo __( 'Copiar linha digitável', 'flexify-checkout-for-woocommerce' ); ?>"><?php echo __( 'Copiar linha digitável', 'flexify-checkout-for-woocommerce' ); ?></button>
</section>
