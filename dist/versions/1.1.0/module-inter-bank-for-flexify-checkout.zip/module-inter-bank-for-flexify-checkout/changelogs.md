Versão 1.1.0 (24/07/2024)
* Correção de bugs
* Otimizações
* Recurso modificado: Boleto bancário com Pix (Atualização na API do banco Inter: https://developers.inter.co/references/cobranca)

Versão 1.0.0 inicial (20/02/2024)